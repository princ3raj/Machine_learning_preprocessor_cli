from django.forms import ModelForm
from .models import Files

class BeastForm(ModelForm):
    class Meta: 
        model = Files
        fields = '__all__'


