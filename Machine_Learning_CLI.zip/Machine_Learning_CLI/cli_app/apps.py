from django.apps import AppConfig


class CliAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cli_app'
