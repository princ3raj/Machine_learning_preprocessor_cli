from django.shortcuts import render

# Create your views here.

from django.http import HttpResponse,HttpResponseRedirect

from .forms import BeastForm
from cli_app.utils.main import Preprocessor

from django.http import HttpResponseRedirect
from django.shortcuts import render


def index(request):

    if request.method=="POST":
        # obj is the object of our Preprocessor class(main class).
        obj = Preprocessor()
        # the object 'obj' calls the main function of our Preprocessor class.
        obj.preprocessorMain()



    return render(request, "cli_app/preprocess.html")
    

def upload(request):

    if request.method == 'POST':
        form = BeastForm(request.POST, request.FILES)
        print(form.is_valid())

        if form.is_valid():
            print("run")
            form.save()
            return HttpResponseRedirect("/") 
    else:
        form = BeastForm()

    return render(request, "cli_app/file_upload.html", {
    "form": form
    })







